<?php
echo '{ "users":[
			{
				"firstName": "Martin",
				"lastName": "White",
				"joined": {
					"month":"July",
					"day":1,
					"year":1989
				}
			},
			{
				"firstName":"Zeeshan",
				"lastName":"Patoli",
				"joined": {
					"month":"January",
					"day":12,
					"year":2012
				}
			}
]}';
?>