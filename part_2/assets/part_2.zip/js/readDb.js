function readdata(){
	
}